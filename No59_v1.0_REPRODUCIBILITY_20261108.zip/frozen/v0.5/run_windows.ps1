$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot
$hashLines = Get-Content -LiteralPath 'SHA256SUMS.txt' -Encoding UTF8
foreach ($line in $hashLines) {
    if ($line -notmatch '^([0-9a-f]{64})  (.+)$') { throw ('Malformed hash manifest line: ' + $line) }
    $expected = $Matches[1]; $relative = $Matches[2]
    $file = Join-Path $PSScriptRoot ($relative -replace '/', '\')
    if (-not (Test-Path -LiteralPath $file -PathType Leaf)) { throw ('Missing: ' + $relative) }
    $actual = (Get-FileHash -LiteralPath $file -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($actual -ne $expected) { throw ('SHA256 mismatch: ' + $relative) }
}
Write-Host 'PASS: SHA256 manifest'
$cxx = Get-Command 'g++' -ErrorAction SilentlyContinue
if ($null -eq $cxx) { throw 'C++17 g++ not found on PATH; no false PASS.' }
$py = Get-Command 'python' -ErrorAction SilentlyContinue
if ($null -eq $py) { throw 'Python 3.10+ not found on PATH; no false PASS.' }
$temp = Join-Path ([System.IO.Path]::GetTempPath()) ('No59_' + [guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $temp | Out-Null
try {
    $exe = Join-Path $temp 'no59_check.exe'
    & $cxx.Source -O2 -std=c++17 -Wall -Wextra -Werror 'code/exhaustive_small_grid.cpp' -o $exe
    if ($LASTEXITCODE -ne 0) { throw 'Compilation failed' }
    $got = Join-Path $temp 'cpp.log'
    & $exe | Out-File -LiteralPath $got -Encoding ascii
    if ($LASTEXITCODE -ne 0) { throw 'C++ verifier failed' }
    $base = [System.IO.File]::ReadAllText((Join-Path $PSScriptRoot 'evidence/cpp_small_grid.log')).Replace("`r`n", "`n")
    $new = [System.IO.File]::ReadAllText($got).Replace("`r`n", "`n")
    if ($base -ne $new) { throw 'C++ output mismatch' }
    $countExe = Join-Path $temp 'no59_count.exe'
    & $cxx.Source -O2 -std=c++17 -Wall -Wextra -Werror 'code/count_successful_four_sets.cpp' -o $countExe
    if ($LASTEXITCODE -ne 0) { throw 'Count compiler failed' }
    $countLog = Join-Path $temp 'count.log'
    & $countExe | Out-File -LiteralPath $countLog -Encoding ascii
    if ($LASTEXITCODE -ne 0) { throw 'Count verifier failed' }
    $expectedCount = [System.IO.File]::ReadAllText((Join-Path $PSScriptRoot 'evidence/successful_four_sets.log')).Replace("`r`n", "`n")
    $actualCount = [System.IO.File]::ReadAllText($countLog).Replace("`r`n", "`n")
    if ($expectedCount -ne $actualCount) { throw 'Four-set count output mismatch' }
    $gotpy = Join-Path $temp 'python.log'
    & $py.Source 'code/independent_bfs_audit.py' | Out-File -LiteralPath $gotpy -Encoding ascii
    if ($LASTEXITCODE -ne 0) { throw 'Python verifier failed' }
    $basepy = [System.IO.File]::ReadAllText((Join-Path $PSScriptRoot 'evidence/python_bfs_small_grid.log')).Replace("`r`n", "`n")
    $newpy = [System.IO.File]::ReadAllText($gotpy).Replace("`r`n", "`n")
    if ($basepy -ne $newpy) { throw 'Independent Python output mismatch' }
    Write-Host 'PASS: C++17 + independent BFS Python (Windows reproduction, when executed)'
} finally { Remove-Item -LiteralPath $temp -Recurse -Force -ErrorAction SilentlyContinue }
