#include <algorithm>
#include <array>
#include <cassert>
#include <cstdint>
#include <iostream>
#include <vector>
using namespace std;
struct Vertex {int x,y,z;};
struct Result {bool found=false;uint64_t tested=0; vector<int> indices;};
vector<Vertex> V; vector<vector<uint8_t>> D;
void init(int a,int b,int c){ V.clear();for(int x=0;x<a;x++)for(int y=0;y<b;y++)for(int z=0;z<c;z++)V.push_back({x,y,z}); int N=V.size();D.assign(N,vector<uint8_t>(N));for(int i=0;i<N;i++)for(int j=0;j<N;j++)D[i][j]=abs(V[i].x-V[j].x)+abs(V[i].y-V[j].y)+abs(V[i].z-V[j].z); }
uint64_t signature(int v,const vector<int>& s){uint8_t arr[8]={0};for(size_t i=0;i<s.size();i++){uint8_t d=D[v][s[i]];size_t j=i;while(j>0 && arr[j-1]>d){arr[j]=arr[j-1];--j;}arr[j]=d;}uint64_t t=0;for(size_t i=0;i<s.size();i++)t=(t<<8)|arr[i];return t;}
bool resolves(const vector<int>& s){uint64_t hashes[100];int h=0;for(int v=0;v<(int)V.size();v++){bool member=false;for(int si:s)if(v==si){member=true;break;}if(member)continue;uint64_t t=signature(v,s);for(int j=0;j<h;j++)if(hashes[j]==t)return false;hashes[h++]=t;}return true;}
Result try_size(int k,bool full_count=true){Result r;int N=V.size();vector<int>s(k);for(int i=0;i<k;i++)s[i]=i;do{r.tested++;if(resolves(s)){r.found=true;r.indices=s;if(!full_count)break;}int j=k-1;while(j>=0&&s[j]==N-k+j)j--;if(j<0)break;s[j]++;for(int t=j+1;t<k;t++)s[t]=s[t-1]+1;}while(true);return r;}
void print(int a,int b,int c,int k,const Result&r){cout<<"P"<<a<<" P"<<b<<" P"<<c<<" k="<<k<<" checked="<<r.tested<<" success="<<r.found; if(r.found){cout<<" set=";for(int idx:r.indices){auto v=V[idx];cout<<"("<<v.x<<","<<v.y<<","<<v.z<<")";}}cout<<"\n"<<flush;}
int main(){for(int m=2;m<=5;m++){for(int n=m;n<=5;n++){init(2,m,n);for(int k=1;k<=3;k++){auto q=try_size(k,false);print(2,m,n,k,q);assert(!q.found);}auto a=try_size(4,false);print(2,m,n,4,a);if(!a.found){auto b=try_size(5,false);print(2,m,n,5,b);if(!b.found){auto c=try_size(6,false);print(2,m,n,6,c);}}}}}
