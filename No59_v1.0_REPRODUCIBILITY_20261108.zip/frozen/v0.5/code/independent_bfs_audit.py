"""Independent adversarial verifier: BFS graph distances and multiset signatures.
No imports of the earlier No59 programs. Pure Python stdlib.
"""
from collections import deque
from itertools import combinations, product
from math import comb

EXPECTED = {(2,2):5,(2,3):5,(2,4):5,(2,5):4,(3,3):5,(3,4):5,(3,5):5,(4,4):5,(4,5):4,(5,5):5}

def instance(m,n):
    vertices=list(product(range(2),range(m),range(n)))
    index={v:i for i,v in enumerate(vertices)}
    adjacent=[]
    for v in vertices:
        js=[]
        for j in range(3):
            for diff in (-1,1):
                nxt=list(v);nxt[j]+=diff;nxt=tuple(nxt)
                if nxt in index:js.append(index[nxt])
        adjacent.append(js)
    dist=[]
    for src in range(len(vertices)):
        d=[-1]*len(vertices); d[src]=0;q=deque([src]);
        while q:
            v=q.popleft()
            for w in adjacent[v]:
                if d[w]<0:d[w]=d[v]+1;q.append(w)
        assert all(x>=0 for x in d)
        dist.append(d)
    return vertices,dist

def distinct_outside(c,dist):
    omit=set(c);seen=set()
    for v in range(len(dist)):
        if v in omit:continue
        sig=tuple(sorted(dist[v][s] for s in c))
        if sig in seen:return False
        seen.add(sig)
    return True

def main():
    for (m,n),expected in EXPECTED.items():
        V,D=instance(m,n)
        assert len(V)==2*m*n
        for k in range(1,5):
            successes=0
            checked=0
            for C in combinations(range(len(V)),k):
                checked+=1
                if distinct_outside(C,D):
                    successes+=1
                    if k==4 and expected==4:
                        break
                    raise AssertionError((m,n,k,C))
            assert checked==comb(len(V),k) if not (k==4 and expected==4) else checked>0
            print('BFS_PYTHON',m,n,'k',k,'checked',checked,'success',successes,flush=True)
            if k==4 and expected==4:assert successes==1
        if expected==5:
            first=next(C for C in combinations(range(len(V)),5) if distinct_outside(C,D))
            print('BFS_WITNESS_5',m,n,[V[i] for i in first],flush=True)
    print('ALL_BFS_PYTHON_CASES_PASS')
if __name__=='__main__':main()
