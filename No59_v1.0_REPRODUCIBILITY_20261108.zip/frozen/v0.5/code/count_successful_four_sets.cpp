#include <algorithm>
#include <array>
#include <cstdint>
#include <cstdio>
#include <vector>
using namespace std;
struct V {int a,b,c;};
static int dist(V u,V v){return abs(u.a-v.a)+abs(u.b-v.b)+abs(u.c-v.c);}
int main(){for(int m: {2,4}){int n=5;vector<V> v;for(int a=0;a<2;a++)for(int b=0;b<m;b++)for(int c=0;c<n;c++)v.push_back({a,b,c});int t=v.size();uint64_t success=0;std::array<int,4> first={};for(int a=0;a<t;a++)for(int b=a+1;b<t;b++)for(int c=b+1;c<t;c++)for(int d=c+1;d<t;d++){int s[]={a,b,c,d};uint32_t signatures[100];int k=0;bool good=true;for(int u=0;u<t;u++){if(u==a||u==b||u==c||u==d)continue;int dv[4];for(int j=0;j<4;j++)dv[j]=dist(v[u],v[s[j]]);sort(dv,dv+4);uint32_t sig=0;for(int j=0;j<4;j++)sig=(sig<<8)|dv[j];for(int i=0;i<k;i++)if(signatures[i]==sig){good=false;break;}if(!good)break;signatures[k++]=sig;}if(good){success++;if(success==1)first={a,b,c,d};}}printf("m=%d n=5 total_successful_four_sets=%llu first=",m,(unsigned long long)success);for(int j:first)printf("(%d,%d,%d)",v[j].a,v[j].b,v[j].c);printf("\n");}}
