#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
sha256sum -c SHA256SUMS.txt
CXX=${CXX:-g++}
D=$(mktemp -d)
trap 'rm -rf "$D"' EXIT
"$CXX" -O2 -std=c++17 -Wall -Wextra -Werror code/exhaustive_small_grid.cpp -o "$D/no59_check"
"$D/no59_check" > "$D/cpp.log"
diff -u evidence/cpp_small_grid.log "$D/cpp.log"
"$CXX" -O2 -std=c++17 -Wall -Wextra -Werror code/count_successful_four_sets.cpp -o "$D/no59_count"
"$D/no59_count" > "$D/count.log"
diff -u evidence/successful_four_sets.log "$D/count.log"
python3 code/independent_bfs_audit.py > "$D/python.log"
diff -u evidence/python_bfs_small_grid.log "$D/python.log"
echo 'PASS: SHA256 and C++/independent Python BFS exact outputs.'
