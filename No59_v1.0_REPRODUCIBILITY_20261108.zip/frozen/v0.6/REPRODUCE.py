#!/usr/bin/env python3
"""Verify v0.6 audit supplement inventory and run the three pure-stdlib checks.
The shipped frozen v0.5 is deliberately not modified or automatically rerun.
"""
from pathlib import Path
import hashlib, subprocess, sys
R=Path(__file__).resolve().parent
rows=(R/'SHA256SUMS.txt').read_text(encoding='utf-8').splitlines()
for row in rows:
    want,relative=row.split('  ',1)
    p=R/relative
    if not p.is_file():raise RuntimeError('Missing: '+relative)
    got=hashlib.sha256(p.read_bytes()).hexdigest()
    if got!=want:raise RuntimeError('SHA256 mismatch: '+relative)
print(f'PASS SHA256: {len(rows)} files',flush=True)
for file in ['verify_local_fold.py','verify_symbolic_branches.py','verify_upper_poly_coefficients.py']:
    print('RUN',file,flush=True)
    subprocess.run([sys.executable,str(R/file)],cwd=R,check=True)
print('PASS: supplementary symbolic and finite checks. General literature novelty NOT certified.',flush=True)
