#!/usr/bin/env python3
"""Independent exact local fold check (4096 sign quadruples; no dependencies)."""
from itertools import product
V=list(product((-1,1),repeat=3))
def det(a,b,c):
    return a[0]*(b[1]*c[2]-b[2]*c[1])-a[1]*(b[0]*c[2]-b[2]*c[0])+a[2]*(b[0]*c[1]-b[1]*c[0])
def add(*xs):return tuple(sum(x[i] for x in xs) for i in range(3))
def mul(n,x):return tuple(n*i for i in x)
opposite=0
for a,b,c,d in product(V,repeat=4):
    u=det(a,b,c);v=det(a,b,d)
    assert u in (-4,0,4) and v in (-4,0,4)
    if u*v<0:
        opposite+=1
        # Compare opposite outer faces of a 1x1x2 double cube.
        shell=[(i,j,k) for i in (0,1) for j in (0,1) for k in (0,2)]
        gradients={p:add(mul(p[0],a),mul(p[1],b),mul(p[2]//2,add(c,d))) for p in shell}
        # Every patch corner at z=0 or z=2 is a true vertex.
        pairs=[(p,q) for p in shell for q in shell if p<q and gradients[p]==gradients[q]]
        assert pairs,(a,b,c,d,u,v)
        # All such collisions have distinct z coordinates (same face map is invertible).
        assert any(p[2]!=q[2] for p,q in pairs)
        alternatives=[(0,0,0),add(a,b),mul(-1,add(a,b)),add(a,mul(-1,b)),add(b,mul(-1,a))]
        assert add(c,d) in alternatives
assert opposite==384,opposite
print('PASS: 4096 sign-vector quadruples, 384 opposite-determinant cases, 384 actual two-face ordered collisions')
