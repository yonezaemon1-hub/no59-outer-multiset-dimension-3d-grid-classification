#!/usr/bin/env python3
"""Independent affine-identity audit of No59 v0.4 outer collision witnesses.
No SymPy/NumPy needed. Checks all 22 explicit algebraic cases as identities in
A,B,C,k. Bounds/parity are mathematical obligations documented separately.
"""
from fractions import Fraction as Q
from itertools import permutations

class F:
    def __init__(self, v=0):
        if isinstance(v,F): self.c=v.c
        elif isinstance(v,(tuple,list)): self.c=tuple(map(Q,v))
        else: self.c=(Q(0),Q(0),Q(0),Q(0),Q(v))
        assert len(self.c)==5
    def __add__(self,o):
        o=F(o);return F(tuple(x+y for x,y in zip(self.c,o.c)))
    __radd__=__add__
    def __neg__(self):return F(tuple(-x for x in self.c))
    def __sub__(self,o):return self+(-F(o))
    def __rsub__(self,o):return F(o)+(-self)
    def __mul__(self,o):
        if isinstance(o,F):assert o.c[:4]==(0,0,0,0);o=o.c[4]
        return F(tuple(x*Q(o) for x in self.c))
    __rmul__=__mul__
    def __truediv__(self,o):return self* (Q(1)/Q(o))
    def __eq__(self,o):return self.c==F(o).c
    def __repr__(self):return str(self.c)
    def calc(self,a,b,c,k):return sum(x*t for x,t in zip(self.c,(a,b,c,k,1)))
A=F((1,0,0,0,0));B=F((0,1,0,0,0));C=F((0,0,1,0,0));K=F((0,0,0,1,0));Z=F(0);O=F(1)

def p(x,y,z):return (F(x),F(y),F(z))

def sigpoint(pt,S,side=None):
    out=[]
    for s in S:
        total=Z
        for axis,(x,sx,edge) in enumerate(zip(pt,s,(A,B,C))):
            if sx==Z: term=x
            elif sx==edge: term=edge-x
            elif axis==2:
                assert side in ('below','above'),(pt,S,side)
                term=sx-x if side=='below' else x-sx
            else:raise ValueError((axis,sx,pt))
            total+=term
        out.append(total)
    return out

def substitute_middle(x):
    # In the special central branch k=C/2, replace k in every expression.
    v=list(x.c)
    v[2]+=v[3]/2
    v[3]=Q(0)
    return F(v)

def audit(name,S,u,v,sideu=None,sidev=None):
    if name=='II-a even k=h':
        S=tuple(tuple(substitute_middle(x) for x in s) for s in S)
        u=tuple(substitute_middle(x) for x in u)
        v=tuple(substitute_middle(x) for x in v)
    du=sigpoint(u,S,sideu);dv=sigpoint(v,S,sidev)
    valid=[perm for perm in permutations(range(3)) if all(du[i]==dv[perm[i]] for i in range(3))]
    if not valid:
        print('FAIL IDENTITY',name,'u',u,'v',v,'du',du,'dv',dv)
        raise AssertionError(name)
    perm=valid[0]
    # Audit full rank: exactly three different landmarks, formal distinctness by affine forms.
    assert len(set(tuple(t.c for t in s) for s in S))==3
    assert u!=v and u not in S and v not in S
    print(f'PASS {name:27s} permutation {perm}')
    return name

cases=[]
def add(name,S,u,v,sideu=None,sidev=None):cases.append((name,S,u,v,sideu,sidev))

a=p(0,0,0);face=p(A,0,0);face_y=p(0,B,0)
S=(a,face,face_y)
h=A/2
add('I-a A even',S,p(h-1,0,1),p(h+1,1,0))
h=B/2
add('I-a B even',S,p(0,h-1,1),p(1,h+1,0))
add('I-a A,B odd',S,p((A+1)/2,(B-1)/2,1),p((A-1)/2,(B+1)/2,1))
S=(a,p(A,B,0),p(A,0,C))
H=(A+B)/2
add('I-b A+B even A<=B',S,p(0,(B-A)/2,1),p(A,H,1))
add('I-b A+B even A>B',S,p((A-B)/2,0,1),p(H,B,1))
H=(A+C)/2
add('I-b A+C even A<=C',S,p(0,1,(C-A)/2),p(A,1,H))
add('I-b A+C even A>C',S,p((A-C)/2,1,0),p(H,1,C))
D=(B-C)/2
add('I-b B+C even D>=0',S,p(0,D,1),p(0,D+1,0))
add('I-b B+C even D<0',S,p(0,0,1-D),p(0,1,-D))
S=(p(0,0,K),p(0,B,0),p(0,B,C))
h=C/2
add('II-a even k<h',S,p(1,1,h-1),p(0,0,h+1),'above','above')
add('II-a even k>h',S,p(0,0,h-1),p(1,1,h+1),'below','below')
add('II-a even k=h',S,p(1,0,h-1),p(1,0,h+1),'below','above')
D=(K-B)/2
add('II-a odd k=B, D>=0',S,p(1,0,D+1),p(1,1,D),'below','below')
add('II-a odd k=B, D<0',S,p(1,-D,1),p(1,1-D,0),'below','below')
H=(B+C+K-2)/2
add('II-a odd k=B+C, H<=C-1',S,p(1,0,H),p(1,1,H+1),'above','above')
add('II-a odd k=B+C, H>C-1',S,p(1,H-C+1,C-1),p(1,H-C+2,C),'above','above')
S=(p(0,0,K),p(0,B,0),p(A,0,0))
D=(K-B)/2
add('II-b k=B, D>=0',S,p(1,0,D+1),p(1,1,D),'below','below')
add('II-b k=B, D<0',S,p(1,-D,1),p(1,1-D,0),'below','below')
D=(K-A)/2
add('II-b k=A, D>=0',S,p(0,1,D+1),p(1,1,D),'below','below')
add('II-b k=A, D<0',S,p(-D,1,1),p(1-D,1,0),'below','below')
D=(B-A)/2
add('II-b A=B, D>=0',S,p(0,D+1,1),p(1,D,1),'below','below')
add('II-b A=B, D<0',S,p(-D,1,1),p(1-D,0,1),'below','below')

if __name__=='__main__':
    print('NO59 INDEPENDENT SYMBOLIC AFFINE IDENTITIES')
    for case in cases:audit(*case)
    print('PASS: all',len(cases),'explicit linear-form identities; no sampling used')

# Conditions are mutually exclusive inside each of the four geometric types.
# Cases are listed in exactly the priority order of the independent proof.
def allowed(name,a,b,c,k):
    ab=(a+b)%2==0;ac=(a+c)%2==0
    if name=='I-a A even':return a%2==0
    if name=='I-a B even':return a%2==1 and b%2==0
    if name=='I-a A,B odd':return a%2==1 and b%2==1
    if name=='I-b A+B even A<=B':return ab and a<=b
    if name=='I-b A+B even A>B':return ab and a>b
    if name=='I-b A+C even A<=C':return not ab and ac and a<=c
    if name=='I-b A+C even A>C':return not ab and ac and a>c
    if name=='I-b B+C even D>=0':return not ab and not ac and b>=c
    if name=='I-b B+C even D<0':return not ab and not ac and b<c
    if name=='II-a even k<h':return c%2==0 and k<c//2
    if name=='II-a even k>h':return c%2==0 and k>c//2
    if name=='II-a even k=h':return c%2==0 and k==c//2
    if name=='II-a odd k=B, D>=0':return c%2 and (k-b)%2==0 and k>=b
    if name=='II-a odd k=B, D<0':return c%2 and (k-b)%2==0 and k<b
    h=(b+c+k-2)//2
    if name=='II-a odd k=B+C, H<=C-1':return c%2 and (k-b)%2 and h<=c-1
    if name=='II-a odd k=B+C, H>C-1':return c%2 and (k-b)%2 and h>c-1
    if name=='II-b k=B, D>=0':return (k-b)%2==0 and k>=b
    if name=='II-b k=B, D<0':return (k-b)%2==0 and k<b
    if name=='II-b k=A, D>=0':return (k-b)%2 and (k-a)%2==0 and k>=a
    if name=='II-b k=A, D<0':return (k-b)%2 and (k-a)%2==0 and k<a
    if name=='II-b A=B, D>=0':return (k-b)%2 and (k-a)%2 and b>=a
    if name=='II-b A=B, D<0':return (k-b)%2 and (k-a)%2 and b<a
    raise AssertionError(name)

def direct_distance(p,s):return sum(abs(x-y) for x,y in zip(p,s))

def verify_integer_box(a,b,c,subset):
    applicable=[r for r in cases if r[0].startswith(subset) and allowed(r[0],a,b,c,1)] if subset in ('I-a','I-b') else None
    if applicable is not None:assert len(applicable)==1,(a,b,c,subset,[r[0] for r in applicable])
    if subset in ('II-a','II-b'):
        for k in range(1,c):
            valid=[r for r in cases if r[0].startswith(subset) and allowed(r[0],a,b,c,k)]
            assert len(valid)==1,(a,b,c,k,subset,[r[0] for r in valid])
            evaluate_one(valid[0],a,b,c,k)
        return c-1
    evaluate_one(applicable[0],a,b,c,1)
    return 1

def evaluate_one(entry,a,b,c,k):
    name,S,u,v,*_=entry
    assert allowed(name,a,b,c,k)
    def resolve(pt):
        coords=tuple(t.calc(a,b,c,k) for t in pt)
        assert all(t.denominator==1 for t in coords),(name,coords,a,b,c,k)
        return tuple(map(int,coords))
    if name=='II-a even k=h':assert k*2==c
    ss=tuple(resolve(s) for s in S);uu=resolve(u);vv=resolve(v)
    assert len(set(ss))==3,(name,ss)
    assert uu!=vv and uu not in ss and vv not in ss,(name,a,b,c,k,ss,uu,vv)
    assert all(all(0<=p[i]<=bound for i,bound in enumerate((a,b,c))) for p in [*ss,uu,vv]),(name,a,b,c,k,uu,vv)
    assert sorted(direct_distance(uu,s) for s in ss)==sorted(direct_distance(vv,s) for s in ss),(name,a,b,c,k,uu,vv)

if __name__=='__main__':
    counts={x[0]:0 for x in cases}
    tests=0
    for a in range(1,13):
        for b in range(1,13):
            for c in range(1,13):
                for category in ('I-a','I-b','II-a','II-b'):
                    tests+=verify_integer_box(a,b,c,category)
    print('PASS: independent integer range, exteriority, uniqueness, parity branch coverage:',tests)
