#!/usr/bin/env python3
"""Independent exact quadratic-coefficient audit of the six moment states.
Six evaluations determine every polynomial of degree <= 2 in L,z; source
base-distance entries are affine in L,z on the stated z-intervals.
"""
from fractions import Fraction as Q

def coeff(f):
    f00=f(0,0);f10=f(1,0);f20=f(2,0);f01=f(0,1);f02=f(0,2);f11=f(1,1)
    cLL=Q(f20-2*f10+f00,2);cL=f10-f00-cLL
    cZZ=Q(f02-2*f01+f00,2);cZ=f01-f00-cZZ
    cLZ=f11-f00-cL-cZ-cLL-cZZ
    return tuple(map(Q,(f00,cL,cZ,cLL,cLZ,cZZ)))

def base(state,L,z):
    if state=='I+':return (z,z+1,L-z,L+2-z)
    if state=='I-':return (z,z-1,L-z,L+2-z)
    if state=='II+':return (L+1,L+2,1,1)
    if state=='II-':return (L+1,L,1,1)
    if state=='III+':return (L+2,L+3,2,0)
    if state=='III-':return (L+2,L+1,2,0)
    raise ValueError(state)
Wcoeff={
'I+':(11,4,-8,4,-16,16),
'I-':(19,12,-24,4,-16,16),
'II+':(3,4,0,4,0,0),
'II-':(3,-4,0,4,0,0),
'III+':(19,12,0,4,0,0),
'III-':(11,4,0,4,0,0)}
Roffset={'I+':3,'I-':1,'II+':5,'II-':3,'III+':7,'III-':5}
for state,want in Wcoeff.items():
    f=lambda L,z:4*sum(x*x for x in base(state,L,z))-sum(base(state,L,z))**2
    got=coeff(f)
    assert got==tuple(map(Q,want)),(state,got,want)
    r=coeff(lambda L,z:sum(base(state,L,z)))
    assert r==(Q(Roffset[state]),Q(2),Q(0),Q(0),Q(0),Q(0)),(state,r)
    print(f'PASS {state} W={tuple(map(int,got))} R=2L+{Roffset[state]}')
print('PASS: all six R mod4 / W coefficient rows as exact quadratic polynomial identities')
