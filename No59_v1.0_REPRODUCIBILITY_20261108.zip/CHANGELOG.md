# No.59 v1.0 publication changes

8 November 2026 · Ryutaro Yonezu

The English manuscript is based on the TeX in the Rev2 archive. The publication edits update the title-page status, PDF metadata, audit scope, distribution notes, and the No.58 citation and attribution. The mathematical body and the appendix containing all short-grid witnesses match the Rev2 TeX byte for byte. The abstract formula and its parameter domain are unchanged. The range-certificate note retains its mathematical scope, branch table, and reproduction instructions.

The Rev2 manifest covered 23 files and matched the original inventory. The following hashes identify the original source and frozen archival ZIPs.

| Input | SHA256 |
| --- | --- |
| No.59 Rev2 ZIP | 0d7df6d7a67dfde5c2f582f9900823be3178fe981483389955ee6fd06f21b7c6 |
| Frozen v0.5 ZIP | 4372e433610d7809aaf613fbb54ce22dac922a4731578bf811fc22633d2cbdc0 |
| Frozen v0.6 ZIP | d731d175e8bc676914ddada52844f73e262dee40bb68d61e436d44cfa2c8f236 |

The original archives were preserved byte for byte. The public ZIP includes the byte-identical v0.5 finite verification code, runners and expected outputs, the byte-identical v0.6 symbolic checkers and runner, and the byte-identical supplemental exact-rational checker, witness definitions and expected output. Manifests were regenerated for this inventory. The complete private archives, their embedded review documents, and the Windows raw transcript were kept out of the public ZIP.

The original Rev2 command and the three reproduction steps from the public ZIP were run on Linux. The author-reported Rev2 AI audit is scope-limited. The author-reported Windows PowerShell 5.1 PASS applies to frozen v0.5 finite computation. REFERENCES PARTIAL. NOVELTY INCONCLUSIVE. Not human peer-reviewed. All rights reserved.
