#!/usr/bin/env python3
"""Exact rational linear-programming verification of No.59's 22 witness cases.

Requires sympy. Uses archived v0.6 symbolic witnesses unmodified; all new
linear minimizations are exact rational arithmetic, not sampling or floats.
Integer integrality/parity and exhaustive branch partition are recorded in
PROOF_22_BRANCH_RANGES.md and are *not* proved by LP alone.
"""
from importlib.util import spec_from_file_location, module_from_spec
from pathlib import Path
from sympy import symbols, Rational, Eq, simplify
from sympy.solvers.simplex import lpmin, InfeasibleLPError, UnboundedLPError

ROOT=Path(__file__).resolve().parent
SCRIPT=ROOT/'reference_v06'/'verify_symbolic_branches.py'
spec=spec_from_file_location('old_no59',SCRIPT); m=module_from_spec(spec); spec.loader.exec_module(m)
A,B,C,K=symbols('A B C K')
vars=(A,B,C,K)

def exp(f):return sum(Rational(n.numerator,n.denominator)*x for n,x in zip(f.c[:4],vars))+Rational(f.c[4].numerator,f.c[4].denominator)

def assumptions(name):
    base=[A>=1,B>=1,C>=1]
    if name.startswith('I-a A even'):return base+[A>=2]
    if name.startswith('I-a B even'):return base+[B>=2]
    if name.startswith('I-a A,B odd'):return base
    if name.startswith('I-b A+B even A<=B'):return base+[B>=A]
    if name.startswith('I-b A+B even A>B'):return base+[A>=B+1]
    if name.startswith('I-b A+C even A<=C'):return base+[C>=A]
    if name.startswith('I-b A+C even A>C'):return base+[A>=C+1]
    if name.startswith('I-b B+C even D>=0'):return base+[B>=C]
    if name.startswith('I-b B+C even D<0'):return base+[C>=B+1]
    base +=[K>=1,C-K>=1]
    if name.startswith('II-a even k<h'):return base+[C>=2,C/2-K>=1]
    if name.startswith('II-a even k>h'):return base+[C>=2,K-C/2>=1]
    if name.startswith('II-a even k=h'):return base+[C>=2,Eq(K,C/2)]
    if name.startswith('II-a odd k=B, D>=0'):return base+[C>=3,K>=B]
    if name.startswith('II-a odd k=B, D<0'):return base+[C>=3,B-K>=1]
    if name.startswith('II-a odd k=B+C, H<=C-1'):return base+[C>=3,C-1-(B+C+K-2)/2>=0]
    if name.startswith('II-a odd k=B+C, H>C-1'):return base+[C>=3,(B+C+K-2)/2-C>=0]
    if name.startswith('II-b k=B, D>=0'):return base+[K>=B]
    if name.startswith('II-b k=B, D<0'):return base+[B-K>=1]
    if name.startswith('II-b k=A, D>=0'):return base+[K>=A]
    if name.startswith('II-b k=A, D<0'):return base+[A-K>=1]
    if name.startswith('II-b A=B, D>=0'):return base+[B>=A]
    if name.startswith('II-b A=B, D<0'):return base+[A-B>=1]
    raise ValueError(name)

cache={}
def minimum(expr, con):
    e=simplify(expr)
    k=(e,tuple(con))
    if k not in cache:
        try: v,solution=lpmin(e,con)
        except UnboundedLPError: v,solution=-float("inf"),{}
        cache[k]=(v,solution)
    return cache[k][0]

bounds_count=sep_count=side_count=0
print('NO59 22-BRANCH EXACT RATIONAL RANGE/EXTERIOR CERTIFICATE')
for name,S,u,v,side_u,side_v in m.cases:
    con=assumptions(name)
    pts=[tuple(map(exp,p)) for p in (u,v)]
    lm=[tuple(map(exp,p)) for p in S]
    # Verify branch constraints are satisfiable over reals.
    try: minimum(A+B+C+(K if name.startswith("II") else 0),con)
    except InfeasibleLPError:raise AssertionError('infeasible branch '+name)
    for p in pts:
        for coord,hi in zip(p,(A,B,C)):
            lo=minimum(coord,con);right=minimum(hi-coord,con)
            assert lo>=0 and right>=0,(name,p,coord,'bounds',lo,right)
            bounds_count+=2
    # Certify absolute-value branches used by the symbolic distance check.
    for p,side in zip(pts,(side_u,side_v)):
        if side:
            gap=K-p[2] if side=='below' else p[2]-K
            assert minimum(gap,con)>=0,(name,side,p,'wrong absolute-value branch')
            side_count+=1
    # Show distinct/exterior via some coordinate difference uniformly >=1.
    for p,q,desc in [(pts[0],pts[1],'u!=v')]+[(pts[i],s,lab) for i,lab in ((0,'u not in S'),(1,'v not in S')) for s in lm]:
        witness=None
        for j,(a,b) in enumerate(zip(p,q)):
            for sign,d in (('+',a-b),('-',b-a)):
                if minimum(d,con)>=1:
                    witness=(j,sign);break
            if witness:break
        assert witness,(name,desc,p,q)
        sep_count+=1
    print(f'PASS {name:32} coordinate bounds + distinctness/exterior')
print('PASS:',len(m.cases),'branches;',bounds_count,'coordinate linear bounds;',sep_count,'uniform separation certificates;',side_count,'absolute-value branch checks; all exact rational LP')
